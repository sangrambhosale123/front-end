import { Component, OnInit } from '@angular/core';
import { usernameService } from '../services/usernameService.service';

@Component({
  selector: 'app-patientdashboard',
  templateUrl: './patientdashboard.component.html',
  styleUrls: ['./patientdashboard.component.css']
})
export class PatientdashboardComponent implements OnInit {
  username:string|undefined;
  constructor(private usernameService:usernameService) { }

  ngOnInit(): void {
    this.username = this.usernameService.getUsername();
  }

}
