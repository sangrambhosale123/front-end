import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewdoctor',
  templateUrl: './viewdoctor.component.html',
  styleUrls: ['./viewdoctor.component.css']
})
export class ViewdoctorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
